/*
 * Copyright 2018-2019 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 *
 */
#include <stdio.h>
#include "fsl_ocotp.h"

#define PRINTF  printf
/***********************************************************************************************************************
 *
 *  Definitions
 *
 **********************************************************************************************************************/
/***********************************************************************************************************************
 *
 *  Variables
 *
 **********************************************************************************************************************/


/***********************************************************************************************************************
 *
 *  Prototypes
 *
 **********************************************************************************************************************/

void main();

/***********************************************************************************************************************
 *
 *  Codes
 *
 **********************************************************************************************************************/
void clock_init(void)
{
    // Assuming that ROM has done the clock initialization
}


void main(void)
{

    PRINTF("Applying ROM Patches...\r\n");


    //static uint32_t s_rompatchBuffer[] = {0x55010001, 0x00204fd0, 0xe7fee7fe};//{0x55010002, 0x0020554c,0x1205f240,0x0020566c,0xbf00011e,0x55020105,0x0020557b, 0x5170f244, 0xf2c42030, 0x600801c8,0x0001f04f,0x47709000, 0x55010101, 0x00205388, 0x2003b081};
    static uint32_t s_rompatchBuffer[] =
    {

        0x55010002,
        0x00205388,
        0x2003b081,
        0x002057ec,
        0x2604f240,

        0x55010102,
        0x00205b60,
        0x4000f24b,
        0x40c4f2c0,

        0x55020110,
        0x00205789,
        0x480bb510,
        0x60012100,
        0x1205f240,
        0x4c096102,
        0x20646823,
        0xf4834908,
        0x60233380,
        0xf44f4788,
        0x4b067280,
        0x6f20601a,
        0x0010f040,
        0xbd106720,
        0x40c84820,
        0x40c84500,
        0x002054df,
        0x40c84580,


        };


    uint32_t s_rompatchCheck[ARRAY_SIZE(s_rompatchBuffer)];

    ocotp_init(OCOTP);

    for (uint32_t i=0; i<ARRAY_SIZE(s_rompatchBuffer); i++)
    {
        (void) ocotp_read_once(OCOTP, 0x91 + i,  &s_rompatchCheck[i], 4);
    }

    uint32_t hasPatchData = 0u;
    for (uint32_t i=0; i<ARRAY_SIZE(s_rompatchBuffer); i++)
    {
        hasPatchData |= s_rompatchCheck[i];
    }

    if (hasPatchData == 0)
    {
        for (uint32_t i=0; i<ARRAY_SIZE(s_rompatchBuffer); i++)
        {
            ocotp_program_once(OCOTP, 0x91 + i, &s_rompatchBuffer[i], 4);
        }

        PRINTF("ROM PATCH has been blown successfully!\n");
    }
    else
    {
        PRINTF("This chip has a patch programmed already!\n");
    }


#if 0

    // Update the ROM boot frequency, for now, only the 696MHz option is usable due to the PLL_LDO enabling issue
    static uint32_t bootFreq = 0x08;
    uint32_t temp;
    ocotp_read_once(OCOTP, 0x1a, &temp, 4);
    if ((temp & bootFreq) != bootFreq)
    {
        ocotp_program_once(OCOTP, 0x1a, &bootFreq, 4);
    }
#endif

    while (1)
    {
    }
}


void hardware_init(void)
{
}

uint32_t get_bus_clock(void)
{
#define FREQ_1MHz 1000000u
#ifndef BL_TARGET_ZEBU
    // PIT is from BUS clock, the maximum bus clock is 200MHz
    uint32_t clkRoot = CCM->CCM_CLOCK_ROOT[kCCM_ClockRootIndex_BUS].CONTROL;
    uint32_t div = (clkRoot & CCM_CCM_CLOCK_ROOT_CONTROL_DIV_MASK) >> CCM_CCM_CLOCK_ROOT_CONTROL_DIV_SHIFT;
    uint32_t mux = (clkRoot & CCM_CCM_CLOCK_ROOT_CONTROL_MUX_MASK) >> CCM_CCM_CLOCK_ROOT_CONTROL_MUX_SHIFT;
    uint32_t busFreq = 0;

    switch (mux)
    {
        default:
        case 0:
            busFreq = FREQ_1MHz * 24u;
            break;
        case 1:
            busFreq = FREQ_1MHz * 24u;
            break;
        case 2:
            busFreq = FREQ_1MHz * 400u;
            break;
        case 3:
            busFreq = FREQ_1MHz * 16u;
            break;
        case 4:
            busFreq = FREQ_1MHz * 480u;
            break;
        case 5:
            busFreq = FREQ_1MHz * 200u;
            break;
        case 6:
            busFreq = FREQ_1MHz * 528u;
            break;
        case 7:
            busFreq = FREQ_1MHz * 297u;
            break;
    }
    return busFreq / (div + 1);
#else
    return 12500000u;
#endif
}